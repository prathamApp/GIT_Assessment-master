package com.pratham.assessment.custom.discrete_view;

/**
 * Created by HP on 23-05-2018.
 */

import android.view.View;

/**
 * Created by yarolegovich on 02.03.2017.
 */

public interface DiscreteScrollItemTransformer {
    void transformItem(View item, float position);
}
